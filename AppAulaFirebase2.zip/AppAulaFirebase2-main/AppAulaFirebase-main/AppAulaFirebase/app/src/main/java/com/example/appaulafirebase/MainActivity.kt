package com.example.appaulafirebase

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.appaulafirebase.ui.theme.AppAulaFirebaseTheme
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppAulaFirebaseTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    AppAulaFirebase()
                }
            }
        }
    }
}

// Representa um usuário cadastrado
data class Pessoa(
    val nome: String = "",
    val idade: String = "",
    val nacionalidade: String = "",
    val pais: String = "",
    val cidade: String = ""
)

@Composable
fun AppAulaFirebase() {
    val db = Firebase.firestore

    var nome by remember { mutableStateOf("") }
    var idade by remember { mutableStateOf("") }
    var nacionalidade by remember { mutableStateOf("") }
    var genero by remember { mutableStateOf("") }
    var cidade by remember { mutableStateOf("") }

    var pessoas by remember { mutableStateOf(listOf<Pessoa>()) }
    var mostrarLista by remember { mutableStateOf(false) }

    val scroll = rememberScrollState()

    fun carregarUsuarios() {
        db.collection("users").get()
            .addOnSuccessListener { resultado ->
                val lista = resultado.map { doc ->
                    Pessoa(
                        nome = doc.getString("nome") ?: "",
                        idade = doc.getString("idade") ?: "",
                        nacionalidade = doc.getString("nacionalidade") ?: "",
                        pais = doc.getString("pais") ?: "",
                        cidade = doc.getString("cidade") ?: ""
                    )
                }
                pessoas = lista
                mostrarLista = true
            }
            .addOnFailureListener { erro ->
                Log.w("FIREBASE", "Erro ao buscar usuários", erro)
            }
    }

    if (mostrarLista) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(scroll)
        ) {
            Text("Usuários Cadastrados", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(16.dp))
            pessoas.forEach {
                Text("• ${it.nome}, ${it.idade} anos, ${it.cidade}/${it.pais}")
                Spacer(modifier = Modifier.height(8.dp))
            }
            Spacer(modifier = Modifier.height(24.dp))
            Button(onClick = { mostrarLista = false }) {
                Text("Voltar")
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .background(MaterialTheme.colorScheme.background),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Cadastro",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(16.dp))

            TextField(
                value = nome,
                onValueChange = { nome = it },
                label = { Text("Nome:") },
                colors = textFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            TextField(
                value = idade,
                onValueChange = { idade = it },
                label = { Text("Idade:") },
                colors = textFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            TextField(
                value = nacionalidade,
                onValueChange = { nacionalidade = it },
                label = { Text("Nacionalidade:") },
                colors = textFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            TextField(
                value = genero,
                onValueChange = { genero = it },
                label = { Text("Gênero:") },
                colors = textFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            TextField(
                value = cidade,
                onValueChange = { cidade = it },
                label = { Text("Cidade") },
                colors = textFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (nome.isNotBlank() && idade.isNotBlank() && nacionalidade.isNotBlank()
                        && genero.isNotBlank() && cidade.isNotBlank()
                    ) {
                        val user = hashMapOf(
                            "nome" to nome,
                            "idade" to idade,
                            "nacionalidade" to nacionalidade,
                            "pais" to genero,
                            "cidade" to cidade
                        )

                        db.collection("users")
                            .add(user)
                            .addOnSuccessListener {
                                Log.d("FIREBASE", "Usuário salvo com sucesso: ${it.id}")
                                carregarUsuarios()
                            }
                            .addOnFailureListener { erro ->
                                Log.w("FIREBASE", "Erro ao salvar usuário", erro)
                            }

                        nome = ""
                        idade = ""
                        nacionalidade = ""
                        genero = ""
                        cidade = ""
                    } else {
                        Log.w("FIREBASE", "Preencha todos os campos antes de enviar")
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Cadastrar")
            }
        }
    }
}

@Composable
fun textFieldColors(): TextFieldColors {
    return TextFieldDefaults.colors(
        focusedContainerColor = MaterialTheme.colorScheme.surface,
        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
        focusedLabelColor = MaterialTheme.colorScheme.primary,
        unfocusedLabelColor = MaterialTheme.colorScheme.primary,
        cursorColor = MaterialTheme.colorScheme.primary
    )
}

@Preview(showBackground = true)
@Composable
fun AppAulaFirebasePreview() {
    AppAulaFirebaseTheme {
        AppAulaFirebase()
    }
}
